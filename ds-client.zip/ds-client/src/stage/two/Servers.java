package stage.two;


public class Servers{
    public String serverName;
    public int serverId;
    public String state;
    public int currStartTime;
    public int cores;
    public int nem;
    public int disk;
}